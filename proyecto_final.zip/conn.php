<?php
$server = 'sql9.freemysqlhosting.net';
$user =  'sql9580559';
$pwd = 'Xfe5zsI3Rm';
$db = 'sql9580559';
$conn = mysqli_connect($server, $user, $pwd, $db);
